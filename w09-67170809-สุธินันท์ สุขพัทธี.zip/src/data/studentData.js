export const studentData = {
  // ข้อมูลส่วนตัว
  name: "สุธินันท์ สุขพัทธี",
  studentId: "67170809",
  year: "ปี 2",
  major: "วิทยาการคอมพิวเตอร์และนวัตกรรมการพัฒนาซอฟต์แวร์",
  faculty: "คณเทคโนโลยีสารสนเทศ",
  university: "มหาวิทยาลัยศรีปทุม",

  introduction: [""],
};

export const courseData = {
  code: "CSI105",
  name: "Front End",
};

export const footerData = {
  university: "มหาวิทยาลัยศรีปทุม",
  facultyAndMajor:
    "คณเทคโนโลยีสารสนเทศ | สาขาวิทยาการคอมพิวเตอร์และนวัตกรรมการพัฒนาซอฟต์แวร์",
};
