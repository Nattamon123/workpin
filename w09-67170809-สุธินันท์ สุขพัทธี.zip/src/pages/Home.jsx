import { studentData } from "../data/studentData";
import "./Home.css";

function Home() {
  return (
    <div className="home-container">
      {/* Hero Section with Split Screen */}
      <section className="hero-section">
        <div className="hero-left">
          <div className="text-content">
            <div className="greeting">
              <span className="line-1">Hello, I'm</span>
              <span className="line-2">{studentData.name}</span>
            </div>

            <div className="student-details">
              <div className="detail-item">
                <svg
                  className="detail-icon"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                </svg>
                <div className="detail-text">
                  <span className="label">Student ID</span>
                  <span className="value">{studentData.studentId}</span>
                </div>
              </div>

              <div className="detail-item">
                <svg
                  className="detail-icon"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z" />
                </svg>
                <div className="detail-text">
                  <span className="label">Major</span>
                  <span className="value">{studentData.major}</span>
                </div>
              </div>

              <div className="detail-item">
                <svg
                  className="detail-icon"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
                <div className="detail-text">
                  <span className="label">Year</span>
                  <span className="value">{studentData.year}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="hero-right">
          <div className="image-container">
            <div className="image-frame">
              <div className="frame-decoration"></div>
              <img
                src="\src\assets\512042121_940793061476808_1444745627659435486_n.jpg"
                alt="Profile"
                className="profile-img"
              />
              <div className="floating-badge">Active</div>
            </div>
          </div>
        </div>
      </section>

      {/* Info Cards Grid */}
      <section className="info-section">
        <div className="section-header">
          <h2 className="section-title">Academic Journey</h2>
          <div className="title-underline"></div>
        </div>

        <div className="cards-grid">
          <div className="info-card card-1">
            <div className="card-icon">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 3L1 9l4 2.18v6L12 21l7-3.82v-6l2-1.09V17h2V9L12 3zm6.82 6L12 12.72 5.18 9 12 5.28 18.82 9zM17 15.99l-5 2.73-5-2.73v-3.72L12 15l5-2.73v3.72z" />
              </svg>
            </div>
            <h3>University</h3>
            <p>{studentData.university}</p>
            <div className="card-pattern"></div>
          </div>

          <div className="info-card card-2">
            <div className="card-icon">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 3L2 12h3v8h14v-8h3L12 3zm0 4l4 4h-3v6h-2v-6H8l4-4z" />
              </svg>
            </div>
            <h3>Faculty</h3>
            <p>{studentData.faculty}</p>
            <div className="card-pattern"></div>
          </div>

          <div className="info-card card-3">
            <div className="card-icon">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
              </svg>
            </div>
            <h3>Major</h3>
            <p>{studentData.major}</p>
            <div className="card-pattern"></div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="about-section">
        <div className="about-container">
          <div className="about-header">
            <h2 className="about-title">About Me</h2>
            <div className="about-decoration">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>

          <div className="about-content">
            {studentData.introduction.map((paragraph, index) => (
              <div key={index} className="about-block">
                <div className="block-number">
                  {String(index + 1).padStart(2, "0")}
                </div>
                <p className="block-text">{paragraph}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <div className="stats-container">
          <div className="stat-item">
            <div className="stat-number">
              <span>{studentData.studentId.slice(-2)}</span>
              <small>ID</small>
            </div>
            <div className="stat-label">Student ID</div>
          </div>

          <div className="stat-divider"></div>

          <div className="stat-item">
            <div className="stat-number">
              <span>{studentData.year}</span>
              <small>Year</small>
            </div>
            <div className="stat-label">Academic Year</div>
          </div>

          <div className="stat-divider"></div>

          <div className="stat-item">
            <div className="stat-number">
              <span>A+</span>
              <small>Grade</small>
            </div>
            <div className="stat-label">Performance</div>
          </div>
        </div>
      </section>

      {/* Floating Elements */}
      <div className="floating-elements">
        <div className="float-element float-1"></div>
        <div className="float-element float-2"></div>
        <div className="float-element float-3"></div>
        <div className="float-element float-4"></div>
      </div>
    </div>
  );
}

export default Home;
